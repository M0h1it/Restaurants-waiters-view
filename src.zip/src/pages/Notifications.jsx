import MenuHeader from "../components/MenuHeader";
import BottomNav from "../components/BottomNav";
import { useState } from "react";
import { FaPhoneAlt, FaFileInvoice, FaReceipt } from "react-icons/fa";
import { MdAddCall } from 'react-icons/md';

export default function Notifications() {

  // Dummy notifications ( simulate API response )
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      table: "Table 04",
      message: "Calling you for a query",
      type: "query",
    },
    {
      id: 2,
      table: "Table 08",
      message: "Asking for bill",
      type: "bill",
    },
  ]);

  const clearNotification = (id) => {
    const updated = notifications.filter(n => n.id !== id);
    setNotifications(updated);
  };

  return (
    <div className="bg-light vh-100 d-flex flex-column">
      
      {/* Header */}
      <MenuHeader />

      <div className="px-3 py-3" style={{ flexGrow: 1, overflowY: "auto" }}>

        {notifications.length === 0 ? (
          <div className="text-center fw-bold mt-5 text-secondary">
            No new notifications
          </div>
        ) : (
          notifications.map((item) => (
            <NotificationCard 
              key={item.id} 
              data={item} 
              onClear={() => clearNotification(item.id)} 
            />
          ))
        )}

      </div>

      <BottomNav />
    </div>
  );
}


function NotificationCard({ data, onClear }) {
  return (
    <div 
      className="d-flex justify-content-between align-items-center bg-white rounded-4 shadow-sm px-3 py-2 mb-3"
      style={{ border: "1px solid #e5e5e5" }}
    >
      <div className="d-flex flex-column">
        
        <div className="d-flex align-items-center gap-2">
          {data.type === "query" ? (
            <FaPhoneAlt className="text-danger" size={18} />
          ) : (
            <FaReceipt className="text-danger" size={18} />
          )}

          <strong>{data.table}</strong>
        </div>

        <small className="text-secondary">{data.message}</small>

      </div>

      <button 
        className="btn btn-sm fw-bold"
        style={{
          background: "#D7000F",
          color: "white",
          borderRadius: "10px",
          padding: "6px 14px",
          fontSize: "13px"
        }}
        onClick={onClear}
      >
        Done
      </button>
    </div>
  );
}
