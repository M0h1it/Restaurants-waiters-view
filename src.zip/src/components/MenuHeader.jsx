import { FaInfoCircle, FaBell, FaUser } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

export default function MenuHeader({ onLogOut, onToggleLegend }) {
  const navigate = useNavigate();

  return (
    <header
      className="d-flex justify-content-between align-items-center px-3 py-3 shadow-sm"
      style={{
        backgroundColor: "#D7000F",
      }}
    >
      {/* LEFT TEXT */}
      <h4 className="m-0 text-white fw-bold">My Tables</h4>

      {/* RIGHT ICONS */}
      <div className="d-flex gap-4 align-items-center">

        <FaInfoCircle
          size={24}
          className="text-white"
          style={{ cursor: "pointer" }}
          onClick={onToggleLegend}
        />

        <div
          onClick={onLogOut}
          className="d-flex flex-column align-items-center"
          style={{ cursor: "pointer" }}
        >
          <FaUser size={24} className="text-white" />
          <small className="text-white" style={{ fontSize: "11px" }}>
            Sign Out
          </small>
        </div>
      </div>
    </header>
  );
}
