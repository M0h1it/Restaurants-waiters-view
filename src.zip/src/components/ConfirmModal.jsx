export default function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div
      className="position-fixed top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center"
      style={{
        background: "rgba(0,0,0,0.5)",
        zIndex: 9999
      }}
    >
      <div className="bg-white p-4 rounded shadow" style={{ width: "300px" }}>
        <p className="fw-bold">{message}</p>

        <div className="d-flex justify-content-end gap-2 mt-3">
          <button className="btn btn-secondary btn-sm" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-danger btn-sm" onClick={onConfirm}>
            Ok
          </button>
        </div>
      </div>
    </div>
  );
}
