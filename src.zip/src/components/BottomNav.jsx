import { FaBell, FaUtensils } from "react-icons/fa";
import { useNavigate, useLocation } from "react-router-dom";

export default function BottomNav({hasNotification }) {
  const navigate = useNavigate();
  const location = useLocation();

  // Determine which page is active
  const isDashboard = location.pathname === "/dashboard";
  const isNotifications = location.pathname === "/notifications";

  return (
    <nav
      className="navbar fixed-bottom bg-white shadow border-top py-1"
      style={{ height: "60px" }}
    >
      <div className="container-fluid d-flex justify-content-around align-items-center">

        {/* My Tables */}
        <button
          onClick={() => navigate("/dashboard")}
          className="btn bg-transparent border-0 text-center d-flex flex-column align-items-center"
        >
          <FaUtensils
            size={22}
            className={isDashboard ? "text-danger" : "text-secondary"}
          />
          <span
            className={`small mt-1 ${
              isDashboard ? "fw-bold text-danger" : "text-secondary"
            }`}
          >
            My Tables
          </span>
        </button>

        {/* Notifications */}
        <button
          onClick={() => navigate("/notifications")}
          className="btn bg-transparent border-0 text-center d-flex flex-column align-items-center"
        >
          <FaBell
            size={22}
            className={isNotifications ? "text-danger" : "text-secondary"}
          />
          {/* 🔴 RED BADGE — Only when notification exists */}
          {hasNotification && (
            <span
              style={{
                position: "absolute",
                top: "0px",
                right: "10px",
                width: "12px",
                height: "12px",
                background: "red",
                borderRadius: "50%",
                border: "2px solid white"
              }}
            ></span>
          )}
          <span
            className={`small mt-1 ${
              isNotifications ? "fw-bold text-danger" : "text-secondary"
            }`}
          >
            Notifications
          </span>
        </button>
      </div>
    </nav>
  );
}
